<?php

$host = '127.0.0.1'; // адрес сервера 
$database = 'u107907_comment'; // имя базы данных
$user = 'u107907_u103620'; // имя пользователя
$password = 'Mirack123'; // пароль
$tabl = 'Zapros';

  $conn = mysqli_connect($host, $user, $password, $database) 
  or die("Ошибка, не удалось подключится к базе данных " . mysqli_error());
  echo "Соединение с MySQL установлено! " . PHP_EOL;
  echo "Информация о сервере: " . mysqli_get_host_info($conn) . PHP_EOL;
  
  $FIO = $_POST["FIO"];
  $DataR = $_POST["DataR"];
  $Address = $_POST["Address"];
  $TypeObr = $_POST["TypeObr"];
  $DObr = $_POST["DObr"];
  $TObr = $_POST["TObr"];
  $Okno = $_POST["Okno"];
  $tel = $_POST["tel"];
  
    //echo "<br>";
  //echo "<br>";
  
    //echo "$FIO";
      //echo "<br>";
  //echo "$Address";
  
  $result = mysqli_query ($conn,"INSERT INTO ".$tabl." (FIO,DataR,Address,TypeObr,DObr,TObr,Okno,tel) VALUES ('$FIO','$DataR','$Address','$TypeObr','$DObr','$TObr','$Okno','$tel')");

echo "<br>";
echo "<br>";

  if (!$result)
  echo "Ошибка! Ваши данные не записаны в Базу Данных ";
  else
  echo ("<div style=\"text-align: center; margin-top: 10px;\">
<font color=\"green\">Ваши данные приняты</font>
 
<a href=\"Pegas.html\">Вернуться назад</a></div>");
mysql_close();

  //echo $sql;

 
  
?>